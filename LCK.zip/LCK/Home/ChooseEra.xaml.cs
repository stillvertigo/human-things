﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Home
{
    /// <summary>
    /// Interaction logic for ChooseEra.xaml
    /// </summary>
    public partial class ChooseEra : Window
    {
        public ChooseEra()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow E = new MainWindow();
            E.ShowDialog();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Information I = new Information();
            I.ShowDialog();
            this.Close();
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void rbnGRE_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void rbnEGY_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
