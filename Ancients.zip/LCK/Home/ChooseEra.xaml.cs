﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Home
{

     
    /// <summary>
    /// Interaction logic for ChooseEra.xaml
    /// </summary>
    public partial class ChooseEra : Window
    {
        
        
        public static string age;
       

        public ChooseEra()
        {
            InitializeComponent();
            
    }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            MainWindow E = new MainWindow();
            E.ShowDialog();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (rbnEGY.IsChecked == true)
            {
                age = "EGY";
                this.Hide();
                TopicSelection T = new TopicSelection();
                T.ShowDialog();
                this.Close();
            }
            else if(rbnGRE.IsChecked == true)
            {
                age = "GRE";
                this.Hide();
                TopicSelection T = new TopicSelection();
                T.ShowDialog();
                this.Close();
            }
            else if(rbnROM.IsChecked == true)
            {
                age = "ROM";
                this.Hide();
                TopicSelection T = new TopicSelection();
                T.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("PLEASE SELECT AN ERA :D ");
            }

            
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void rbnGRE_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void rbnEGY_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
