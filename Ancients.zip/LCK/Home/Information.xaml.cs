﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace Home
{
    /// <summary>
    /// Interaction logic for Information.xaml
    /// </summary>
    public partial class Information : Window
    {

        string info = TopicSelection.topic;
        string age = ChooseEra.age;



        public Information()
        {
            InitializeComponent();

            txtInfo.Text = File.ReadAllText(@"C:\Users\\g17e4476\source\repos\LCK\\Info\" +age+@"\"+info+".txt");
            
            
            
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            QuizPage Q = new QuizPage();
            Q.ShowDialog();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            TopicSelection T = new TopicSelection();
            T.ShowDialog();
            this.Close();
        }

        private void txtInfo_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
