﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Home
{
    /// <summary>
    /// Interaction logic for TopicSelection.xaml
    /// </summary>
    public partial class TopicSelection : Window
    {

        string choosen = ChooseEra.age;
        public static string topic;




        public TopicSelection()
        {
            InitializeComponent();

            switch (choosen)
            {
                case "GRE":

                    rbnFig.Content = "ARCA";
                    rbnMyth.Content = "ZEUS";
                    break;
                case "ROM":

                    rbnFig.Content = "CAESAR";
                    rbnMyth.Content = "MARS";
                    break;
                case "EGY":

                    rbnFig.Content = "TUT";
                    rbnMyth.Content = "RAH";
                    break;

                default:
                    MessageBox.Show("greetings you've managed to get this far without clicking radio buttons");
                    break;


            }

        }

        private void btnLoadInf_Click(object sender, RoutedEventArgs e)
        {
            if (rbnMyth.IsChecked == true)
            {
                topic = Convert.ToString(rbnMyth.Content);
                this.Hide();
                Information I = new Information();
                I.ShowDialog();
                this.Close();
            }
            else if (rbnFig.IsChecked == true)
            {
                topic = Convert.ToString(rbnFig.Content);
                this.Hide();
                Information I = new Information();
                I.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("SELECT A TOPIC PLEASE ");
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            ChooseEra E = new ChooseEra();
            E.ShowDialog();
            this.Close();
        }
    }
}


